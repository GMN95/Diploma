import time
import sys
import Adafruit_DHT
import RPi.GPIO as GPIO
from smbus2 import SMBusWrapper
from mysql  import connector

twoBytes = 2

db_user_name = 'own_pi'
db_password = 'password'
db_name = 'tempbase'
db_host = '192.168.0.104'
db_port = 3306

airFlow_adr = 0x49
airFlow_id  = 2

DHT11_pin = 18
DHT11_id  = 1


def airFlow_init(bus):
    time.sleep(15.0 / 1000.0)
    bus.read_i2c_block_data(airFlow_adr, 0, twoBytes)
    time.sleep(15.0 / 1000.0)
    bus.read_i2c_block_data(airFlow_adr, 0, twoBytes)    
    #Read the airflow sensor uuid
    
def airFlow_read(bus):
    data = bus.read_i2c_block_data(airFlow_adr, 0, twoBytes)
    
    high = ( (data[0] & 0x3F) << 8 )
    low  = data[1]
    
    raw = 0x0000
    raw = (raw | high ) | low
    
    return ( ((raw * 20) - 32768) / 13107.2 )
        
def airFlow_write(con, flow):
    currentTimeDate = time.strftime('%Y-%m-%d %H:%M:%S')
    
    cur = con.cursor()
    cur.execute("INSERT INTO `airflow_data` (`sensor_id`, `value`, `unit`, `datetime`) VALUES (airFlow_id, flow, 'SLPM', currentTimeDate);")
    con.commit()
    
def DHT11_init():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(DHT11_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)
    
    return GPIO.input(DHT11_pin)


def DHT11_write(con):
    currentTimeDate = time.strftime('%Y-%m-%d %H:%M:%S')    
    humidity, temperature = Adafruit_DHT.read_retry(11, 4)
    
    cur = con.cursor()
    cur.execute("INSERT INTO `temperature_data` (`sensor_id`, `value`, `unit`, `datetime`) VALUES (DHT11_id, temperature, 'celsius', currentTimeDate);")
    con.commit()
    cur.execute("INSERT INTO `humidity_data` (`sensor_id`, `value`, `unit`, `datetime`) VALUES (DHT11_id, humidity, 'percentage', currentTimeDate);")
    con.commit()

with SMBusWrapper(1) as bus:
    con = connector.Connect(user = db_user_name, password = db_password, database = db_name, host = db_host, port = db_port)
    
    airFlow_init()
    DHT11_init()
    
    time.sleep(15.0 / 1000.0)
    
    while(True):
        flow = airFlow_read(bus)
        airFlow_write(con, flow)
        time.sleep(1)
    
    
    
        
        
        
        
    
    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        